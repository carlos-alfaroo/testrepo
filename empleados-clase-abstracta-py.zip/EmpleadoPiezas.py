from Empleado import Empleado
class EmpleadoPiezas(Empleado):
    #constructor
    def __init__(self, nombre, cantPzVendidas, pagoPorPieza):
        super().__init__(nombre)
        self.CantPzVendidas = cantPzVendidas
        self.PagoPorPieza = pagoPorPieza
    
    #getters
    @property
    def CantPzVendidas(self):
        return self._cantPzVendidas
    @property
    def PagoPorPieza(self):
        return self._pagoPorPieza
        
    #setters
    @CantPzVendidas.setter
    def CantPzVendidas(self,value):
        self._cantPzVendidas = value if value >= 0 else 0
    @PagoPorPieza.setter
    def PagoPorPieza(self, value):
        self._pagoPorPieza = value if value > 0 else 0
        
    #methods
    def pagoDiario(self):
        return (self._pagoPorPieza * self._cantPzVendidas)
    def imprimir(self):
        print("Empleado = [Empleado por piezas]   Nombre = [" + self._nombre + "]  Cantidad pz vendidas = [" + str(self._cantPzVendidas) + "]     Pago por pieza = ["+ str(self._pagoPorPieza)+"]")