import Jefe as J
import TrabajadorComision as TC
import EmpleadoPiezas as EP

jefe1 = J.Jefe("carlos",100);
jefe1.imprimir();

trabajadorC = TC.TrabajadorComision("Jose", 100, 10, 5);
trabajadorC.imprimir();

empP = EP.EmpleadoPiezas("Chucho", 10,5);
empP.imprimir();
