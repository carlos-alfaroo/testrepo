from Empleado import Empleado
class Jefe(Empleado):
    #constructor
    def __init__(self, nombre, salarioSemanal):
        super().__init__(nombre)
        self.SalarioSemanal = salarioSemanal
        
    #getter
    @property
    def SalarioSemanal(self):
        return self._salarioSemanal
    
    #setter
    @SalarioSemanal.setter
    def SalarioSemanal(self,value):
        self._salarioSemanal = value if value > 0 else 0
        
    #methods
    def pagoDiario(self):
        return (self._salarioSemanal / 5)
        
    def imprimir(self):
        print("Empleado = [Jefe]   Nombre = [" + self._nombre + "]  Salario Semanal = [" + str(self._salarioSemanal) + "]")