from abc import ABC, abstractmethod

class Empleado(ABC):
    #constructor
    def __init__(self, nombre):
        self.Nombre = nombre
        
    #getter
    @property
    def Nombre(self):
        return self._Nombre
        
    #setter
    @Nombre.setter
    def Nombre(self, nombre):
        self._nombre = nombre if (nombre != "") else "Sin definir."
        
    #methods
    @abstractmethod
    def pagoDiario(self):
        pass
    @abstractmethod
    def imprimir(self):
        pass