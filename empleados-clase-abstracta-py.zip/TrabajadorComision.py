from Empleado import Empleado
class TrabajadorComision(Empleado):
    #constructor
    def __init__(self, nombre, salarioBaseDiario, porcentajeComision, ventas):
        super().__init__(nombre)
        self.SalarioBaseDiario = salarioBaseDiario
        self.PorcentajeComision = porcentajeComision
        self.Ventas = ventas
        
    #getters
    @property
    def SalarioBaseDiario(self):
        return self._salarioBaseDiario
    @property
    def PorcentajeComision(self):
        return self._porcentajeComision
    @property
    def Ventas(self):
        return self._ventas
        
    #setters
    @SalarioBaseDiario.setter
    def SalarioBaseDiario(self, value):
        self._salarioBaseDiario = value if value > 0 else 0
    @PorcentajeComision.setter
    def PorcentajeComision(self, value):
        self._porcentajeComision = value if value > 0 else 0
    @Ventas.setter
    def Ventas(self,value):
        self._ventas = value if value >= 0 else 0
        
    #methods
    def pagoDiario(self):
        return (self._salarioBaseDiario * self._porcentajeComision)/100
        
    def imprimir(self):
        print("Empleado = [Trabajador Comision]   Nombre = [" + self._nombre + "]  Salario Base Diario = [" + str(self._salarioBaseDiario) + "]" + "Porcentaje Comision = [" + str(self._porcentajeComision) + "]  Ventas = [" + str(self._ventas) + "]")